package kr.ac.kopo.answer.service;

import java.util.List;

import kr.ac.kopo.answer.vo.AdminAnswerVO;

public class AdminAnswerServiceImpl implements AdminAnswerService {

	@Override
	public void addAnswer(AdminAnswerVO adminAnswer) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateAnswer(AdminAnswerVO adminAnswer) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteAnswer(Long answerId) {
		// TODO Auto-generated method stub

	}

	@Override
	public AdminAnswerVO getAnswerById(Long answerId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<AdminAnswerVO> getAllAnswers() {
		// TODO Auto-generated method stub
		return null;
	}

}
